package com.github.quattrobg.greenbelt.exam;

public interface IClickable {
	public String Click();
}
