package com.github.quattrobg.greenbelt.exam;

public class Label extends Widget{
	public Label(double x, double y, String text){
		this.x = x;
		this.y = y;
		this.text = text;
	}
}
